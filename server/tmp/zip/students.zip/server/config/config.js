var appRoot = require('app-root-path');

module.exports.viewDir = appRoot + "\\client\\views\\";